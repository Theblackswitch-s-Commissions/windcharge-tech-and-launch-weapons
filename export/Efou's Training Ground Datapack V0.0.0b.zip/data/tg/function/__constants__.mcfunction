scoreboard objectives add use_windcharge minecraft.used:minecraft.wind_charge
scoreboard objectives add prev_pos_x dummy
scoreboard objectives add prev_pos_y dummy
scoreboard objectives add prev_pos_z dummy
scoreboard objectives add motion_x dummy
scoreboard objectives add motion_y dummy
scoreboard objectives add motion_z dummy
scoreboard objectives add score_menu dummy
scoreboard objectives add __tg__temp__ dummy
scoreboard objectives add __tg__vars__ dummy
scoreboard objectives add __tg__constant__ dummy
scoreboard players set !_1 __tg__constant__ 1
scoreboard players set !_2 __tg__constant__ 2
scoreboard players set !_16 __tg__constant__ 16
scoreboard players set !_0 __tg__constant__ 0
