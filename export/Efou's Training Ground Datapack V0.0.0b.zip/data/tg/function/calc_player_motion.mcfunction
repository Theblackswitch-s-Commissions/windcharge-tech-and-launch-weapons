execute as @a run function tg:with_0
