function tg:windcharge/explode/run
kill @n[type=minecraft:wind_charge]
