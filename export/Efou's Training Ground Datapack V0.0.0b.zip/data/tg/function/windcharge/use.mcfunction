advancement revoke @s only tg:events/windcharge/use_consume_item
scoreboard players set @s use_windcharge 0
scoreboard players operation !score_log_in0 __tg__vars__ = @s motion_x
function __flare_stdlib__:__flare_math_score_log
scoreboard players operation #hor_motion_1_3 __tg__temp__ = !score_log_out __tg__vars__
scoreboard players operation #hor_motion_1_3 __tg__temp__ *= !_2 __tg__constant__
scoreboard players operation !score_exp_in0 __tg__vars__ = #hor_motion_1_3 __tg__temp__
function __flare_stdlib__:__flare_math_score_exp
scoreboard players operation #hor_motion_1 __tg__temp__ = !score_exp_out __tg__vars__
scoreboard players operation !score_log_in0 __tg__vars__ = @s motion_z
function __flare_stdlib__:__flare_math_score_log
scoreboard players operation #hor_motion_1_215_217 __tg__temp__ = !score_log_out __tg__vars__
scoreboard players operation #hor_motion_1_215_217 __tg__temp__ *= !_2 __tg__constant__
scoreboard players operation !score_exp_in0 __tg__vars__ = #hor_motion_1_215_217 __tg__temp__
function __flare_stdlib__:__flare_math_score_exp
scoreboard players operation #hor_motion_1_215 __tg__temp__ = !score_exp_out __tg__vars__
scoreboard players operation #hor_motion_1 __tg__temp__ += #hor_motion_1_215 __tg__temp__
scoreboard players operation !score_sqrt_in0 __tg__vars__ = #hor_motion_1 __tg__temp__
function __flare_stdlib__:__flare_math_score_sqrt
scoreboard players operation #hor_motion temp = !score_sqrt_out __tg__vars__
execute if score @s prev_pos_y matches 4000.. if score #hor_motion temp matches ..2000 if predicate tg:is_above_ground if entity @s[x_rotation=70..] run function tg:generated_1
