execute unless function theblackswitch:v2.0/patch-3/version_control/is_latest run return fail
scoreboard players set #tbs-v2.0.enabled.overlay tbs.server_data 1
function theblackswitch:v2.0/patch-3/clear_item/enable
