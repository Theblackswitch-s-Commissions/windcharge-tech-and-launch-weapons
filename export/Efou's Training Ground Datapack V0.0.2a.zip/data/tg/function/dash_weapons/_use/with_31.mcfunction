particle minecraft:cloud ~ ~ ~ 0.3 0.3 0.3 0.04 5
playsound minecraft:entity.breeze.jump master @a ~ ~ ~ 0.5 1
function tg:dash_weapons/launch/run
scoreboard players set !b11 __tg__temp__ 0
execute if entity @s[gamemode=survival] run scoreboard players set !b11 __tg__temp__ 1
execute if score !b11 __tg__temp__ matches 0 if entity @s[gamemode=adventure] run scoreboard players set !b11 __tg__temp__ 1
execute if score !b11 __tg__temp__ matches 1 run tag @s add GIVE_BACK
