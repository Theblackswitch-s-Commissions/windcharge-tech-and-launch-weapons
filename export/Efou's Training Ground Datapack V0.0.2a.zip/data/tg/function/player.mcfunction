execute if score @s use_windcharge matches 1.. run function tg:_player/generated_33
function tg:stunslam_detect/check_on_ground
function tg:dash_weapons/copy
