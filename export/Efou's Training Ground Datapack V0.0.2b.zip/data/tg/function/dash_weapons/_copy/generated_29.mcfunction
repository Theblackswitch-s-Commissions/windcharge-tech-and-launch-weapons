say hello
tag @s remove GIVE_BACK
execute unless items entity @s weapon.mainhand * run return run item replace entity @s weapon.mainhand from entity @s armor.body tg:clear_when_dropped
execute unless items entity @s weapon.offhand * run return run item replace entity @s weapon.offhand from entity @s armor.body tg:clear_when_dropped
tag @s add SELECT
execute summon chest_minecart run function tg:dash_weapons/_copy/_generated_29/with_30
tag @s remove SELECT
return 0
