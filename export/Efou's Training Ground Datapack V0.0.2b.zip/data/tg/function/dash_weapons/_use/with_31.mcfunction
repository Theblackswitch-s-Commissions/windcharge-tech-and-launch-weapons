particle minecraft:cloud ~ ~ ~ 0.3 0.3 0.3 0.04 5
playsound minecraft:entity.breeze.jump master @a ~ ~ ~ 0.5 1
function tg:dash_weapons/launch/run
scoreboard players set !elif11 __tg__temp__ 0
execute if score !elif11 __tg__temp__ matches 0 if predicate tg:holding/mainhand/dashable run function tg:dash_weapons/_use/_with_31/generated_32
execute if score !elif11 __tg__temp__ matches 0 if predicate tg:holding/mainhand/offhand run function tg:dash_weapons/_use/_with_31/generated_33
scoreboard players set !b12 __tg__temp__ 0
execute if entity @s[gamemode=survival] run scoreboard players set !b12 __tg__temp__ 1
execute if score !b12 __tg__temp__ matches 0 if entity @s[gamemode=adventure] run scoreboard players set !b12 __tg__temp__ 1
execute if score !b12 __tg__temp__ matches 1 run tag @s add GIVE_BACK
