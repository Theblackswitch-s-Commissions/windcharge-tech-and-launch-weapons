scoreboard players set !elif9 __tg__temp__ 0
execute if score !elif9 __tg__temp__ matches 0 if predicate tg:holding/mainhand/dashable run function tg:dash_weapons/_copy/generated_27
execute if score !elif9 __tg__temp__ matches 0 if predicate tg:holding/mainhand/offhand run function tg:dash_weapons/_copy/generated_28
scoreboard players set !ret10 __tg__temp__ 0
execute if entity @s[tag=GIVE_BACK] store result score !ret10 __tg__temp__ run function tg:dash_weapons/_copy/generated_29
execute if score !ret10 __tg__temp__ matches 1 run return 1
