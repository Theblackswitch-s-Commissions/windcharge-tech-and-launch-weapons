advancement revoke @s only tg:events/dash_weapons/use_minecraft_consume_item
execute at @s run function tg:dash_weapons/_use/with_31
