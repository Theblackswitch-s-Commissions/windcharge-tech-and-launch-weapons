scoreboard players set @s use_windcharge 0
execute if score @s motion_y matches ..-250 if predicate tg:is_above_ground if entity @s[x_rotation=70..] run function tg:_player/_generated_35/generated_37
